"""FinGuard-AI: U.S. Financial Fraud and Consumer Harm Risk Intelligence Dashboard.

Research prototype only. The scoring logic is transparent, rules-based, and intended
for demonstration, research, and governance discussions—not production decisions.
"""

from __future__ import annotations

import math
import re
from datetime import date
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import plotly.express as px
import streamlit as st

APP_TITLE = "FinGuard-AI"
APP_SUBTITLE = "U.S. Financial Fraud and Consumer Harm Risk Intelligence Dashboard"
PROJECT_DIR = Path(__file__).resolve().parent
SAMPLE_DATA_PATH = PROJECT_DIR / "sample_data.csv"
REQUIRED_COLUMNS = [
    "case_id",
    "date",
    "state",
    "narrative",
    "amount_lost",
    "payment_channel",
    "institution_type",
    "outcome",
]

TYPOLOGY_RULES: dict[str, list[tuple[str, int]]] = {
    "APP scam": [
        ("authorized push payment", 8),
        ("authorized the transfer", 6),
        ("sent the money myself", 5),
        ("peer to peer", 4),
        ("p2p", 4),
        ("real time payment", 4),
        ("instant payment", 4),
        ("payment app", 3),
        ("zelle-like", 3),
        ("transfer was authorized", 5),
    ],
    "bank impersonation scam": [
        ("pretended to be my bank", 9),
        ("claimed to be from the bank", 8),
        ("bank fraud department", 7),
        ("spoofed bank number", 8),
        ("caller id showed my bank", 7),
        ("one-time passcode", 5),
        ("otp", 5),
        ("verification code", 4),
        ("move money to a safe account", 9),
        ("safe account", 6),
        ("bank security team", 6),
    ],
    "invoice redirection / business email compromise": [
        ("invoice", 4),
        ("vendor email", 6),
        ("supplier email", 6),
        ("business email compromise", 10),
        ("payment instructions changed", 9),
        ("wire instructions changed", 9),
        ("new bank details", 7),
        ("closing agent email", 7),
        ("title company email", 7),
        ("accounts payable", 5),
        ("ceo requested", 6),
    ],
    "marketplace scam": [
        ("online marketplace", 8),
        ("marketplace seller", 7),
        ("marketplace buyer", 7),
        ("item never arrived", 6),
        ("fake listing", 7),
        ("shipping fee", 4),
        ("deposit for the item", 5),
        ("classified ad", 5),
        ("payment outside the platform", 7),
        ("rental listing", 5),
    ],
    "romance scam": [
        ("dating app", 7),
        ("romantic relationship", 8),
        ("online relationship", 7),
        ("said they loved me", 7),
        ("military deployment", 5),
        ("travel emergency", 4),
        ("future together", 5),
        ("romance scam", 10),
        ("fiance", 4),
        ("partner overseas", 5),
    ],
    "investment scam": [
        ("investment platform", 8),
        ("guaranteed return", 7),
        ("crypto investment", 8),
        ("trading coach", 6),
        ("investment opportunity", 5),
        ("profits shown", 5),
        ("withdrawal fee", 7),
        ("tax before withdrawal", 7),
        ("pig butchering", 10),
        ("broker was not licensed", 7),
    ],
    "AML / mule-account risk": [
        ("received funds for someone else", 9),
        ("forward the money", 8),
        ("keep a commission", 7),
        ("money mule", 10),
        ("multiple incoming transfers", 7),
        ("rapidly sent onward", 8),
        ("cash out", 5),
        ("new account", 3),
        ("structuring", 8),
        ("source of funds", 5),
        ("pass-through account", 9),
    ],
    "medical debt / credit stress": [
        ("medical debt", 9),
        ("hospital bill", 7),
        ("medical collection", 8),
        ("credit report", 4),
        ("debt collector", 5),
        ("insurance adjustment", 4),
        ("billing error", 4),
        ("credit score dropped", 6),
        ("unexpected medical bill", 7),
        ("collection account", 5),
    ],
    "mortgage or insurance stress": [
        ("mortgage servicer", 8),
        ("foreclosure", 8),
        ("escrow", 5),
        ("loan modification", 6),
        ("home insurance", 6),
        ("insurance claim", 5),
        ("premium increased", 4),
        ("lapse notice", 5),
        ("force-placed insurance", 8),
        ("payment was misapplied", 6),
    ],
    "financial reporting / disclosure integrity concern": [
        ("financial statements", 7),
        ("misstated revenue", 9),
        ("undisclosed related party", 9),
        ("material omission", 8),
        ("false disclosure", 8),
        ("earnings report", 6),
        ("audit concern", 7),
        ("internal controls", 6),
        ("valuation was inflated", 8),
        ("investor disclosure", 6),
    ],
}

TYPOLOGY_BASE_RISK = {
    "APP scam": 58,
    "bank impersonation scam": 72,
    "invoice redirection / business email compromise": 74,
    "marketplace scam": 50,
    "romance scam": 65,
    "investment scam": 68,
    "AML / mule-account risk": 80,
    "medical debt / credit stress": 24,
    "mortgage or insurance stress": 28,
    "financial reporting / disclosure integrity concern": 56,
    "other": 20,
}

PAYMENT_CHANNEL_RISK = {
    "wire transfer": 14,
    "instant payment": 13,
    "p2p payment": 13,
    "cryptocurrency": 15,
    "gift card": 14,
    "cash": 12,
    "ach": 9,
    "debit card": 7,
    "credit card": 4,
    "check": 6,
    "not applicable": 0,
    "unknown": 2,
}

SEVERITY_ORDER = ["Low", "Moderate", "High", "Critical"]


def clamp(value: float, minimum: int = 0, maximum: int = 100) -> int:
    """Clamp and round a score to an integer within the requested range."""
    return int(round(max(minimum, min(maximum, value))))


def normalize_text(text: Any) -> str:
    """Normalize free text for transparent phrase matching."""
    normalized = str(text or "").lower()
    normalized = normalized.replace("’", "'").replace("–", "-").replace("—", "-")
    normalized = re.sub(r"[^a-z0-9$%\s\-']", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def _contains(text: str, phrase: str) -> bool:
    """Match phrases and single terms without using opaque embeddings."""
    phrase = normalize_text(phrase)
    if " " in phrase or "-" in phrase:
        return phrase in text
    return re.search(rf"\b{re.escape(phrase)}\b", text) is not None


def _matched_phrases(text: str, rules: Iterable[tuple[str, int]]) -> list[dict[str, Any]]:
    matches: list[dict[str, Any]] = []
    for phrase, weight in rules:
        if _contains(text, phrase):
            matches.append({"indicator": phrase, "weight": weight})
    return matches


def classify_typology(narrative: str) -> dict[str, Any]:
    """Classify a narrative using explicit weighted phrase rules.

    Returns the selected typology, matched phrases, all category scores, and a
    transparent confidence indicator. Confidence is not a probability.
    """
    text = normalize_text(narrative)
    category_scores: dict[str, int] = {}
    category_matches: dict[str, list[dict[str, Any]]] = {}

    for typology, rules in TYPOLOGY_RULES.items():
        matches = _matched_phrases(text, rules)
        category_matches[typology] = matches
        category_scores[typology] = sum(item["weight"] for item in matches)

    ranked = sorted(category_scores.items(), key=lambda item: item[1], reverse=True)
    top_typology, top_score = ranked[0] if ranked else ("other", 0)
    second_score = ranked[1][1] if len(ranked) > 1 else 0

    if top_score <= 0:
        top_typology = "other"
        confidence = 15
    else:
        evidence_count = len(category_matches[top_typology])
        separation = max(0, top_score - second_score)
        confidence = clamp(35 + (top_score * 2.3) + (evidence_count * 5) + separation, 20, 95)

    return {
        "typology": top_typology,
        "confidence": confidence,
        "matched_indicators": category_matches.get(top_typology, []),
        "category_scores": category_scores,
        "alternative_typologies": [
            {"typology": name, "rule_score": score}
            for name, score in ranked[1:4]
            if score > 0
        ],
    }


def _amount_value(amount_lost: Any) -> float:
    try:
        if pd.isna(amount_lost):
            return 0.0
        return max(0.0, float(amount_lost))
    except (TypeError, ValueError):
        return 0.0


def _outcome_text(outcome: Any) -> str:
    return normalize_text(outcome)


def calculate_fraud_risk(
    narrative: str,
    typology: str,
    amount_lost: float = 0,
    payment_channel: str = "unknown",
    outcome: str = "",
) -> dict[str, Any]:
    """Calculate fraud risk from typology, transaction, and deception indicators."""
    text = normalize_text(narrative)
    amount = _amount_value(amount_lost)
    channel = normalize_text(payment_channel)
    score = float(TYPOLOGY_BASE_RISK.get(typology, 20))
    factors = [{"factor": f"Base risk for {typology}", "effect": int(score)}]

    indicators = [
        ("one-time passcode", 10, "Credential or authentication-code compromise"),
        ("verification code", 8, "Authentication-code disclosure"),
        ("remote access", 12, "Remote-device control"),
        ("screen sharing", 10, "Screen-sharing or device-control indicator"),
        ("spoofed", 9, "Spoofed identity or communication channel"),
        ("urgent", 5, "Pressure or urgency tactic"),
        ("safe account", 9, "False safe-account instruction"),
        ("password", 7, "Credential exposure"),
        ("account takeover", 14, "Account-takeover indicator"),
        ("changed payment instructions", 9, "Payment-redirection indicator"),
        ("guaranteed return", 7, "Implausible return promise"),
        ("keep a commission", 9, "Mule recruitment incentive"),
    ]
    for phrase, points, label in indicators:
        if _contains(text, phrase):
            score += points
            factors.append({"factor": label, "effect": points})

    channel_points = 2
    for known_channel, points in PAYMENT_CHANNEL_RISK.items():
        if known_channel in channel:
            channel_points = points
            break
    if channel_points:
        score += channel_points
        factors.append({"factor": f"Payment channel: {payment_channel}", "effect": channel_points})

    amount_points = 0
    if amount >= 100_000:
        amount_points = 15
    elif amount >= 25_000:
        amount_points = 11
    elif amount >= 5_000:
        amount_points = 7
    elif amount >= 1_000:
        amount_points = 4
    if amount_points:
        score += amount_points
        factors.append({"factor": f"Loss amount: ${amount:,.0f}", "effect": amount_points})

    outcome_normalized = _outcome_text(outcome)
    if any(_contains(outcome_normalized, term) for term in ["confirmed fraud", "account closed for fraud"]):
        score += 6
        factors.append({"factor": "Outcome indicates confirmed fraud concern", "effect": 6})

    return {"score": clamp(score), "factors": factors}


def calculate_consumer_harm(
    narrative: str,
    typology: str,
    amount_lost: float = 0,
    payment_channel: str = "unknown",
    outcome: str = "",
) -> dict[str, Any]:
    """Estimate financial, vulnerability, and essential-service consumer harm."""
    text = normalize_text(narrative)
    amount = _amount_value(amount_lost)
    score = 8.0
    factors = [{"factor": "Baseline consumer impact", "effect": 8}]

    if amount >= 100_000:
        amount_points = 65
    elif amount >= 50_000:
        amount_points = 56
    elif amount >= 10_000:
        amount_points = 45
    elif amount >= 5_000:
        amount_points = 36
    elif amount >= 1_000:
        amount_points = 27
    elif amount > 0:
        amount_points = 16
    else:
        amount_points = 5
    score += amount_points
    factors.append({"factor": f"Magnitude of reported loss: ${amount:,.0f}", "effect": amount_points})

    vulnerability_indicators = [
        (["elderly", "senior", "retired", "fixed income"], 12, "Potential age or fixed-income vulnerability"),
        (["disability", "disabled"], 10, "Disability-related vulnerability"),
        (["limited english", "language barrier"], 8, "Potential language-access barrier"),
        (["medical treatment", "hospital", "medication", "medical debt"], 10, "Health-related financial stress"),
        (["mortgage", "foreclosure", "rent", "eviction"], 11, "Housing stability impact"),
        (["food", "utilities", "paycheck", "life savings"], 10, "Essential funds or savings affected"),
        (["account drained", "entire balance", "all my savings"], 14, "Severe depletion of available funds"),
        (["repeat victim", "second time", "again"], 8, "Repeat-victimization indicator"),
        (["anxiety", "distress", "could not sleep", "embarrassed"], 6, "Reported emotional or behavioral harm"),
    ]
    for phrases, points, label in vulnerability_indicators:
        if any(_contains(text, phrase) for phrase in phrases):
            score += points
            factors.append({"factor": label, "effect": points})

    if typology in {"romance scam", "investment scam"}:
        score += 5
        factors.append({"factor": "Typology often involves extended manipulation", "effect": 5})

    outcome_normalized = _outcome_text(outcome)
    if any(_contains(outcome_normalized, term) for term in ["denied", "no refund", "unrecovered", "closed without reimbursement"]):
        score += 8
        factors.append({"factor": "Reported loss remains unrecovered", "effect": 8})
    elif any(_contains(outcome_normalized, term) for term in ["full refund", "fully recovered", "resolved with reimbursement"]):
        score -= 12
        factors.append({"factor": "Reported full recovery reduces continuing harm", "effect": -12})

    return {"score": clamp(score), "factors": factors}


def calculate_dispute_friction(
    narrative: str,
    typology: str,
    amount_lost: float = 0,
    payment_channel: str = "unknown",
    outcome: str = "",
) -> dict[str, Any]:
    """Measure reported difficulty obtaining review, communication, or remediation."""
    text = normalize_text(narrative)
    outcome_normalized = _outcome_text(outcome)
    score = 10.0
    factors = [{"factor": "Baseline dispute handling effort", "effect": 10}]

    friction_rules = [
        (["denied", "claim denied"], 28, "Claim or reimbursement denial"),
        (["closed the case", "case was closed", "closed without"], 20, "Case closure without satisfactory resolution"),
        (["no response", "never responded", "no call back"], 20, "No timely response reported"),
        (["called repeatedly", "multiple calls", "contacted them several times", "five calls"], 14, "Repeated consumer contacts"),
        (["transferred", "passed between departments"], 10, "Repeated transfers or fragmented ownership"),
        (["requested the same documents", "resubmit", "submitted documents again"], 12, "Duplicative evidence requests"),
        (["appeal", "reconsideration"], 11, "Escalation or appeal required"),
        (["provisional credit removed", "temporary credit reversed"], 17, "Provisional credit reversal"),
        (["complaint", "regulator"], 7, "External complaint or escalation"),
        (["more than 30 days", "60 days", "90 days", "months"], 12, "Extended resolution timeline"),
    ]
    combined = f"{text} {outcome_normalized}"
    for phrases, points, label in friction_rules:
        if any(_contains(combined, phrase) for phrase in phrases):
            score += points
            factors.append({"factor": label, "effect": points})

    if any(_contains(outcome_normalized, term) for term in ["full refund", "resolved", "reimbursed", "recovered"]):
        score -= 14
        factors.append({"factor": "Reported resolution reduces continuing friction", "effect": -14})

    return {"score": clamp(score), "factors": factors}


def _parse_case_date(case_date: Any) -> date | None:
    if case_date is None or (isinstance(case_date, float) and math.isnan(case_date)):
        return None
    try:
        return pd.to_datetime(case_date, errors="raise").date()
    except (ValueError, TypeError, OverflowError):
        return None


def calculate_recovery_urgency(
    narrative: str,
    typology: str,
    fraud_risk_score: int,
    amount_lost: float = 0,
    payment_channel: str = "unknown",
    outcome: str = "",
    case_date: Any = None,
) -> dict[str, Any]:
    """Estimate the time sensitivity of freeze, recall, tracing, or preservation steps."""
    text = normalize_text(narrative)
    outcome_normalized = _outcome_text(outcome)
    amount = _amount_value(amount_lost)
    channel = normalize_text(payment_channel)
    score = 12.0
    factors = [{"factor": "Baseline recovery time sensitivity", "effect": 12}]

    urgent_channels = {
        "wire transfer": 27,
        "instant payment": 27,
        "p2p payment": 25,
        "cryptocurrency": 26,
        "gift card": 24,
        "cash": 22,
        "ach": 16,
        "debit card": 13,
        "credit card": 8,
        "check": 10,
    }
    for known_channel, points in urgent_channels.items():
        if known_channel in channel:
            score += points
            factors.append({"factor": f"Recovery-sensitive channel: {payment_channel}", "effect": points})
            break

    if typology in {
        "APP scam",
        "bank impersonation scam",
        "invoice redirection / business email compromise",
        "AML / mule-account risk",
    }:
        score += 15
        factors.append({"factor": "Typology may benefit from rapid tracing or receiving-side action", "effect": 15})

    if fraud_risk_score >= 80:
        score += 15
        factors.append({"factor": "Very high fraud risk score", "effect": 15})
    elif fraud_risk_score >= 65:
        score += 9
        factors.append({"factor": "High fraud risk score", "effect": 9})

    temporal_indicators = [
        (["today", "this morning", "just happened", "minutes ago"], 20, "Narrative indicates very recent activity"),
        (["yesterday", "last night", "within 24 hours"], 14, "Narrative indicates recent activity"),
        (["pending", "still processing"], 16, "Transaction may still be pending"),
        (["freeze", "recall", "stop payment"], 8, "Immediate recovery action is contemplated"),
    ]
    for phrases, points, label in temporal_indicators:
        if any(_contains(text, phrase) for phrase in phrases):
            score += points
            factors.append({"factor": label, "effect": points})

    parsed_date = _parse_case_date(case_date)
    if parsed_date:
        days_old = (date.today() - parsed_date).days
        if 0 <= days_old <= 3:
            score += 14
            factors.append({"factor": f"Case date is {days_old} day(s) old", "effect": 14})
        elif 4 <= days_old <= 14:
            score += 8
            factors.append({"factor": f"Case date is {days_old} days old", "effect": 8})

    if amount >= 25_000:
        score += 10
        factors.append({"factor": "Large amount may justify accelerated coordination", "effect": 10})
    elif amount >= 5_000:
        score += 5
        factors.append({"factor": "Material loss amount", "effect": 5})

    if any(_contains(outcome_normalized, term) for term in ["full refund", "fully recovered", "funds recalled"]):
        score -= 35
        factors.append({"factor": "Reported recovery reduces active urgency", "effect": -35})
    elif any(_contains(outcome_normalized, term) for term in ["pending", "unresolved", "no refund", "denied"]):
        score += 6
        factors.append({"factor": "Outcome remains unresolved", "effect": 6})

    return {"score": clamp(score), "factors": factors}


def generate_recommendation(
    typology: str,
    fraud_risk_score: int,
    consumer_harm_score: int,
    dispute_friction_score: int,
    recovery_urgency_score: int,
    narrative: str = "",
    payment_channel: str = "unknown",
    outcome: str = "",
) -> str:
    """Generate a concise, case-oriented recommendation from visible rules."""
    text = normalize_text(narrative)
    channel = normalize_text(payment_channel)
    outcome_text = _outcome_text(outcome)

    if typology == "AML / mule-account risk":
        primary = "Check receiving-side mule-account indicators and preserve transaction tracing records."
    elif typology == "bank impersonation scam":
        primary = "Escalate for bank-impersonation and APP scam review."
    elif typology == "APP scam":
        primary = "Escalate for APP scam review and assess reimbursement eligibility."
    elif typology == "invoice redirection / business email compromise":
        primary = "Initiate beneficiary-bank outreach and wire recall review."
    elif typology == "marketplace scam":
        primary = "Request platform, payment, listing, and communications evidence."
    elif typology == "romance scam":
        primary = "Monitor for repeat victimization and review linked payment recipients."
    elif typology == "investment scam":
        primary = "Review investment-solicitation evidence and trace destination accounts or wallets."
    elif typology == "medical debt / credit stress":
        primary = "Validate billing, collection authority, and credit-reporting accuracy."
    elif typology == "mortgage or insurance stress":
        primary = "Escalate servicing or claims review and request a complete transaction history."
    elif typology == "financial reporting / disclosure integrity concern":
        primary = "Preserve supporting records and route for disclosure-integrity review."
    else:
        primary = "Request additional evidence and route for manual risk review."

    actions: list[str] = [primary]
    if recovery_urgency_score >= 70 and not any(_contains(outcome_text, term) for term in ["full refund", "fully recovered"]):
        actions.append("Initiate freeze, recall, or stop-payment steps where operationally available.")
    if dispute_friction_score >= 65:
        actions.append("Conduct a senior-level dispute-handling review and document the rationale for the outcome.")
    if consumer_harm_score >= 75:
        actions.append("Apply heightened consumer-harm handling and monitor for repeat victimization.")
    if fraud_risk_score >= 80 and typology != "AML / mule-account risk":
        actions.append("Check receiving-side account, device, and beneficiary risk indicators.")
    if any(term in text for term in ["otp", "one-time passcode", "password", "remote access"]):
        actions.append("Assess credential compromise and secure affected access channels.")
    if "cryptocurrency" in channel:
        actions.append("Preserve wallet addresses, transaction hashes, and exchange details.")

    # Keep the recommendation short enough for a case queue.
    return " ".join(actions[:3])


def score_band(score: int) -> str:
    if score >= 85:
        return "Critical"
    if score >= 70:
        return "High"
    if score >= 45:
        return "Moderate"
    return "Low"


def analyze_case(case: dict[str, Any] | pd.Series) -> dict[str, Any]:
    """Run the complete explainable analysis for one complaint or fraud case."""
    row = dict(case)
    narrative = str(row.get("narrative", ""))
    amount = _amount_value(row.get("amount_lost", 0))
    payment_channel = str(row.get("payment_channel", "unknown"))
    outcome = str(row.get("outcome", ""))

    typology_result = classify_typology(narrative)
    typology = typology_result["typology"]
    fraud = calculate_fraud_risk(narrative, typology, amount, payment_channel, outcome)
    harm = calculate_consumer_harm(narrative, typology, amount, payment_channel, outcome)
    friction = calculate_dispute_friction(narrative, typology, amount, payment_channel, outcome)
    urgency = calculate_recovery_urgency(
        narrative,
        typology,
        fraud["score"],
        amount,
        payment_channel,
        outcome,
        row.get("date"),
    )
    recommendation = generate_recommendation(
        typology,
        fraud["score"],
        harm["score"],
        friction["score"],
        urgency["score"],
        narrative,
        payment_channel,
        outcome,
    )

    result = dict(row)
    result.update(
        {
            "typology": typology,
            "classification_confidence": typology_result["confidence"],
            "fraud_risk_score": fraud["score"],
            "consumer_harm_score": harm["score"],
            "dispute_friction_score": friction["score"],
            "recovery_urgency_score": urgency["score"],
            "overall_severity": score_band(max(fraud["score"], harm["score"], urgency["score"])),
            "recommendation": recommendation,
            "matched_indicators": ", ".join(
                match["indicator"] for match in typology_result["matched_indicators"]
            )
            or "No category-specific phrase matched",
            "typology_explanation": typology_result,
            "fraud_explanation": fraud,
            "harm_explanation": harm,
            "friction_explanation": friction,
            "urgency_explanation": urgency,
        }
    )
    return result


def analyze_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Validate and analyze a portfolio of cases."""
    clean = df.copy()
    clean.columns = [str(column).strip().lower() for column in clean.columns]
    missing = [column for column in REQUIRED_COLUMNS if column not in clean.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")

    clean = clean[REQUIRED_COLUMNS].copy()
    clean["amount_lost"] = pd.to_numeric(clean["amount_lost"], errors="coerce").fillna(0)
    clean["date"] = pd.to_datetime(clean["date"], errors="coerce")
    records = [analyze_case(row) for _, row in clean.iterrows()]
    return pd.DataFrame(records)


def _display_score_chart(result: dict[str, Any]) -> None:
    scores = pd.DataFrame(
        {
            "Dimension": ["Fraud Risk", "Consumer Harm", "Dispute Friction", "Recovery Urgency"],
            "Score": [
                result["fraud_risk_score"],
                result["consumer_harm_score"],
                result["dispute_friction_score"],
                result["recovery_urgency_score"],
            ],
        }
    )
    fig = px.bar(
        scores,
        x="Score",
        y="Dimension",
        orientation="h",
        range_x=[0, 100],
        text="Score",
        color="Score",
        color_continuous_scale=["#e7f5f3", "#f5c96a", "#b42318"],
    )
    fig.update_traces(textposition="outside")
    fig.update_layout(
        height=310,
        margin=dict(l=10, r=30, t=20, b=20),
        coloraxis_showscale=False,
        yaxis_title=None,
        xaxis_title="Risk score (0–100)",
    )
    st.plotly_chart(fig, use_container_width=True)


def _factor_table(title: str, explanation: dict[str, Any]) -> None:
    st.markdown(f"**{title}**")
    factors = pd.DataFrame(explanation.get("factors", []))
    if factors.empty:
        st.caption("No additional factors were triggered.")
    else:
        factors["effect"] = factors["effect"].map(lambda value: f"{value:+d}")
        st.dataframe(factors, use_container_width=True, hide_index=True)


def _render_single_case() -> None:
    st.subheader("Single-case narrative analysis")
    st.caption("Enter a complaint or fraud narrative. The result is generated from visible phrase and scoring rules.")

    with st.form("single_case_form"):
        narrative = st.text_area(
            "Complaint or fraud narrative",
            height=190,
            placeholder=(
                "Example: A caller claiming to be from my bank's fraud department told me to move "
                "money to a safe account and asked for a one-time passcode..."
            ),
        )
        col1, col2, col3 = st.columns(3)
        with col1:
            amount_lost = st.number_input("Amount lost (USD)", min_value=0.0, value=0.0, step=100.0)
        with col2:
            payment_channel = st.selectbox(
                "Payment channel",
                [
                    "unknown",
                    "instant payment",
                    "P2P payment",
                    "wire transfer",
                    "ACH",
                    "debit card",
                    "credit card",
                    "cryptocurrency",
                    "gift card",
                    "check",
                    "cash",
                    "not applicable",
                ],
            )
        with col3:
            outcome = st.selectbox(
                "Current outcome",
                [
                    "unresolved",
                    "claim pending",
                    "denied - no refund",
                    "partial recovery",
                    "full refund",
                    "information only",
                ],
            )
        submitted = st.form_submit_button("Analyze case", type="primary", use_container_width=True)

    if not submitted:
        return
    if not narrative.strip():
        st.warning("Enter a narrative before running the analysis.")
        return

    result = analyze_case(
        {
            "case_id": "MANUAL-CASE",
            "date": date.today().isoformat(),
            "state": "Not provided",
            "narrative": narrative,
            "amount_lost": amount_lost,
            "payment_channel": payment_channel,
            "institution_type": "Not provided",
            "outcome": outcome,
        }
    )

    st.markdown("---")
    left, right = st.columns([1.1, 1])
    with left:
        st.markdown("##### Classification")
        st.markdown(f"### {result['typology']}")
        st.caption(
            f"Rule confidence indicator: {result['classification_confidence']}/100. "
            "This is an evidence-strength indicator, not a statistical probability."
        )
        st.info(result["recommendation"], icon="🛡️")
    with right:
        _display_score_chart(result)

    score_columns = st.columns(4)
    labels = [
        ("Fraud Risk", result["fraud_risk_score"]),
        ("Consumer Harm", result["consumer_harm_score"]),
        ("Dispute Friction", result["dispute_friction_score"]),
        ("Recovery Urgency", result["recovery_urgency_score"]),
    ]
    for column, (label, score) in zip(score_columns, labels):
        column.metric(label, f"{score}/100", score_band(score))

    st.markdown("##### Explainability: matched typology indicators")
    matches = result["typology_explanation"]["matched_indicators"]
    if matches:
        match_df = pd.DataFrame(matches).rename(columns={"indicator": "Matched phrase", "weight": "Rule weight"})
        st.dataframe(match_df, use_container_width=True, hide_index=True)
    else:
        st.caption("No category-specific phrase matched; the case was assigned to 'other'.")

    alternatives = result["typology_explanation"]["alternative_typologies"]
    if alternatives:
        st.caption("Other categories with matched evidence:")
        st.dataframe(pd.DataFrame(alternatives), use_container_width=True, hide_index=True)

    with st.expander("View full scoring audit trail", expanded=False):
        _factor_table("Fraud Risk Score", result["fraud_explanation"])
        _factor_table("Consumer Harm Score", result["harm_explanation"])
        _factor_table("Dispute Friction Score", result["friction_explanation"])
        _factor_table("Recovery Urgency Score", result["urgency_explanation"])


def _load_sample_data() -> pd.DataFrame:
    return pd.read_csv(SAMPLE_DATA_PATH)


def _prepare_download(df: pd.DataFrame) -> bytes:
    export_columns = REQUIRED_COLUMNS + [
        "typology",
        "classification_confidence",
        "fraud_risk_score",
        "consumer_harm_score",
        "dispute_friction_score",
        "recovery_urgency_score",
        "overall_severity",
        "matched_indicators",
        "recommendation",
    ]
    return df[export_columns].to_csv(index=False).encode("utf-8")


def _render_batch_dashboard() -> None:
    st.subheader("Portfolio dashboard")
    st.caption("Use the included synthetic demonstration cases or upload a CSV with the required schema.")

    source = st.radio(
        "Data source",
        ["Synthetic sample data", "Upload CSV"],
        horizontal=True,
        label_visibility="collapsed",
    )

    raw_df: pd.DataFrame | None = None
    if source == "Synthetic sample data":
        raw_df = _load_sample_data()
        st.success("Loaded 30 synthetic demonstration cases. No real consumer data are included.")
    else:
        uploaded = st.file_uploader("Upload complaint/fraud cases", type=["csv"])
        if uploaded is not None:
            try:
                raw_df = pd.read_csv(uploaded)
            except Exception as exc:  # Streamlit should display a readable validation message.
                st.error(f"Could not read the CSV: {exc}")

    with st.expander("Required CSV columns"):
        st.code(", ".join(REQUIRED_COLUMNS), language="text")

    if raw_df is None:
        st.info("Upload a CSV to create the portfolio dashboard.")
        return

    try:
        analyzed = analyze_dataframe(raw_df)
    except ValueError as exc:
        st.error(str(exc))
        return

    total_cases = len(analyzed)
    high_risk = analyzed[
        (analyzed["fraud_risk_score"] >= 70)
        | (analyzed["consumer_harm_score"] >= 75)
        | (analyzed["recovery_urgency_score"] >= 75)
    ]
    metrics = st.columns(5)
    metrics[0].metric("Total cases", f"{total_cases:,}")
    metrics[1].metric("High-risk cases", f"{len(high_risk):,}")
    metrics[2].metric("Average fraud risk", f"{analyzed['fraud_risk_score'].mean():.1f}")
    metrics[3].metric("Average dispute friction", f"{analyzed['dispute_friction_score'].mean():.1f}")
    metrics[4].metric("Reported amount lost", f"${analyzed['amount_lost'].sum():,.0f}")

    chart_left, chart_right = st.columns(2)
    with chart_left:
        distribution = (
            analyzed["typology"].value_counts().rename_axis("Typology").reset_index(name="Cases")
        )
        fig_type = px.bar(
            distribution.sort_values("Cases"),
            x="Cases",
            y="Typology",
            orientation="h",
            title="Scam and risk typology distribution",
            text="Cases",
        )
        fig_type.update_layout(height=460, margin=dict(l=10, r=20, t=55, b=30), yaxis_title=None)
        st.plotly_chart(fig_type, use_container_width=True)

    with chart_right:
        severity_counts = (
            analyzed["overall_severity"]
            .value_counts()
            .reindex(SEVERITY_ORDER, fill_value=0)
            .rename_axis("Severity")
            .reset_index(name="Cases")
        )
        fig_harm = px.bar(
            severity_counts,
            x="Severity",
            y="Cases",
            title="Consumer harm and recovery severity",
            text="Cases",
            category_orders={"Severity": SEVERITY_ORDER},
            color="Severity",
            color_discrete_map={
                "Low": "#4f8f86",
                "Moderate": "#d7a63d",
                "High": "#d2603d",
                "Critical": "#8e1b16",
            },
        )
        fig_harm.update_layout(height=460, margin=dict(l=20, r=20, t=55, b=30), showlegend=False)
        st.plotly_chart(fig_harm, use_container_width=True)

    st.markdown("##### High-risk case queue")
    high_risk_table = high_risk[
        [
            "case_id",
            "date",
            "state",
            "typology",
            "amount_lost",
            "fraud_risk_score",
            "consumer_harm_score",
            "dispute_friction_score",
            "recovery_urgency_score",
            "recommendation",
        ]
    ].sort_values(
        ["recovery_urgency_score", "fraud_risk_score", "consumer_harm_score"], ascending=False
    )
    st.dataframe(
        high_risk_table,
        use_container_width=True,
        hide_index=True,
        column_config={
            "amount_lost": st.column_config.NumberColumn("Amount Lost", format="$%.2f"),
            "date": st.column_config.DateColumn("Date", format="YYYY-MM-DD"),
            "fraud_risk_score": st.column_config.ProgressColumn("Fraud Risk", min_value=0, max_value=100),
            "consumer_harm_score": st.column_config.ProgressColumn("Consumer Harm", min_value=0, max_value=100),
            "dispute_friction_score": st.column_config.ProgressColumn("Dispute Friction", min_value=0, max_value=100),
            "recovery_urgency_score": st.column_config.ProgressColumn("Recovery Urgency", min_value=0, max_value=100),
        },
    )

    st.markdown("##### All analyzed cases")
    display_columns = REQUIRED_COLUMNS + [
        "typology",
        "fraud_risk_score",
        "consumer_harm_score",
        "dispute_friction_score",
        "recovery_urgency_score",
        "overall_severity",
        "recommendation",
    ]
    st.dataframe(
        analyzed[display_columns].sort_values("fraud_risk_score", ascending=False),
        use_container_width=True,
        hide_index=True,
    )
    st.download_button(
        "Download analyzed cases",
        data=_prepare_download(analyzed),
        file_name="finguard_ai_analyzed_cases.csv",
        mime="text/csv",
        use_container_width=True,
    )


def _render_methodology_summary() -> None:
    st.subheader("Explainable and auditable design")
    st.markdown(
        """
FinGuard-AI uses a **rules-first** architecture. Each classification and score is produced from
visible phrase matches, typology base values, transaction attributes, loss magnitude, reported
vulnerability, dispute-handling indicators, and recovery time sensitivity.

The prototype intentionally avoids opaque model outputs. An analyst can inspect:

- the phrases that matched each typology;
- the points added or subtracted for every score;
- the alternative typologies with matching evidence; and
- the decision rules that generated the recommended next action.

This design supports research on fraud operations, APP scams, AML and mule-account indicators,
consumer-harm measurement, dispute governance, and accountable FinTech controls. It is not a
substitute for legal review, suspicious activity reporting procedures, sanctions screening,
institutional case management, or human adjudication.
"""
    )
    st.info(
        "Research prototype limitation: scores are heuristic and have not been calibrated or validated "
        "against representative institutional or public complaint datasets.",
        icon="ℹ️",
    )


def _apply_theme() -> None:
    st.markdown(
        """
<style>
    .block-container {padding-top: 1.5rem; padding-bottom: 3rem; max-width: 1450px;}
    [data-testid="stMetric"] {background: #f7f9fb; border: 1px solid #e3e8ee; padding: 0.8rem; border-radius: 0.65rem;}
    .prototype-banner {background: #fff6df; border: 1px solid #e7c873; padding: .8rem 1rem; border-radius: .65rem; margin-bottom: 1rem;}
    .hero {padding: 1.1rem 1.2rem; border-radius: .8rem; background: linear-gradient(105deg, #0b3142, #174f5d); color: white; margin-bottom: 1rem;}
    .hero h1 {margin: 0; font-size: 2rem;}
    .hero p {margin: .35rem 0 0 0; color: #d9eef0;}
</style>
""",
        unsafe_allow_html=True,
    )


def main() -> None:
    st.set_page_config(page_title=f"{APP_TITLE} | Research Prototype", page_icon="🛡️", layout="wide")
    _apply_theme()
    st.markdown(
        f"""
<div class="hero">
  <h1>{APP_TITLE}</h1>
  <p>{APP_SUBTITLE}</p>
</div>
<div class="prototype-banner">
  <strong>Research prototype:</strong> Synthetic demonstration data and heuristic rules only. Not production-ready and not intended for automated adverse decisions.
</div>
""",
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.markdown("### Governance position")
        st.caption(
            "FinGuard-AI demonstrates an explainable, reviewable workflow for financial fraud and consumer-harm risk intelligence."
        )
        st.markdown("**Design principles**")
        st.markdown("- Rules first\n- Human review\n- Visible evidence\n- Auditable scores\n- Synthetic demo data")
        st.markdown("---")
        st.caption("Prototype version 1.0")

    tab_single, tab_dashboard, tab_method = st.tabs(
        ["Analyze a Narrative", "Portfolio Dashboard", "Methodology & Governance"]
    )
    with tab_single:
        _render_single_case()
    with tab_dashboard:
        _render_batch_dashboard()
    with tab_method:
        _render_methodology_summary()

    st.markdown("---")
    st.caption(
        "FinGuard-AI is a research prototype for demonstration and NIW evidence development. "
        "It does not provide legal advice, compliance determinations, or production fraud decisions."
    )


if __name__ == "__main__":
    main()

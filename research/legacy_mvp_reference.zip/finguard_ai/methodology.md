# FinGuard-AI Methodology

## Status and purpose

FinGuard-AI is an explainable research prototype for financial fraud and consumer-harm risk intelligence. It is designed to demonstrate a practical, auditable analytics architecture for U.S. fraud operations, APP scams, AML and mule-account indicators, dispute governance, recovery prioritization, and consumer protection.

The prototype is not production-ready. The rules and thresholds have not been validated against a representative population, institutional loss data, public complaint data, confirmed fraud labels, or regulatory outcomes.

## Analytical workflow

For each narrative, the prototype performs six steps:

1. Normalize the text to lowercase and remove nonessential punctuation.
2. Match visible keywords and phrases against typology rule lists.
3. Select the category with the highest weighted rule score.
4. Calculate four separate 0–100 risk scores.
5. preserve the factors and points that created each score.
6. Generate a short recommendation from the typology and score thresholds.

No embeddings, generative model, hidden prompt, or black-box classifier is required for the MVP.

## Typology categories

### APP scam

Covers narratives in which the consumer or business appears to have authorized a payment because of deception. Indicators include authorized push payment language, instant or peer-to-peer transfers, payment-app use, and statements that the consumer sent the money personally.

### Bank impersonation scam

Covers false bank fraud departments, spoofed caller identification, false security teams, one-time passcodes, verification codes, and instructions to move funds to a supposed safe account.

### Invoice redirection / business email compromise

Covers changed payment instructions, altered wire details, compromised vendor or supplier email, closing-agent impersonation, executive payment requests, and accounts-payable redirection.

### Marketplace scam

Covers fake listings, deposits, off-platform payment, nonexistent goods, fraudulent rentals, shipping-fee demands, and sellers or buyers that disappear.

### Romance scam

Covers prolonged online relationships, declarations of love, fabricated emergencies, overseas partners, deployment stories, future-together claims, and repeated financial requests.

### Investment scam

Covers guaranteed returns, unlicensed brokers, fake trading platforms, manipulated profit displays, cryptocurrency investments, withdrawal fees, and demands for taxes before funds can be released.

### AML / mule-account risk

Covers receiving funds for another person, keeping a commission, multiple incoming transfers, rapid onward movement, cash-out behavior, pass-through accounts, structuring references, and source-of-funds concerns. These are risk indicators, not findings of criminal activity.

### Medical debt / credit stress

Covers hospital or medical bills, debt collection, credit-report disputes, insurance adjustments, unexpected medical balances, collection accounts, and credit-score effects.

### Mortgage or insurance stress

Covers mortgage servicing, foreclosure, escrow, loan modification, force-placed insurance, premium or claim disputes, misapplied payments, and housing-related financial stress.

### Financial reporting / disclosure integrity concern

Covers financial statement concerns, misstated revenue, related-party omissions, false or incomplete disclosures, valuation inflation, weak internal controls, audit concerns, and investor-reporting integrity.

### Other

Used when no category-specific phrase is matched. This category should receive human review if the narrative still appears consequential.

## Classification logic

Each typology contains a list of phrases and a visible weight. Highly specific phrases receive larger weights than broad phrases. For example, “move money to a safe account” receives more weight than a generic reference to a payment app.

The selected category is the category with the highest total matched weight. The interface also shows alternative categories with matched evidence.

The classification confidence indicator is an evidence-strength heuristic based on:

- total matched rule weight;
- number of matched phrases; and
- separation between the top two categories.

It is not a calibrated probability and must not be interpreted as one.

## Fraud Risk Score

The Fraud Risk Score estimates how strongly the case resembles deliberate deception, account compromise, payment redirection, or illicit-funds movement.

### Inputs

- typology base risk;
- payment-channel reversibility and speed;
- credential or one-time-passcode compromise;
- remote access or screen sharing;
- spoofing and false safe-account instructions;
- urgency or pressure tactics;
- account-takeover language;
- implausible return promises;
- mule recruitment incentives;
- amount lost; and
- outcomes that explicitly indicate confirmed fraud concerns.

### Interpretation

- `0–44`: Low
- `45–69`: Moderate
- `70–84`: High
- `85–100`: Critical

The score is a triage indicator, not a conclusion that fraud occurred.

## Consumer Harm Score

The Consumer Harm Score estimates the practical severity of the reported impact.

### Inputs

- amount lost;
- age, retirement, fixed-income, disability, or language-access vulnerability;
- medical, housing, food, utility, paycheck, or life-savings impact;
- account depletion;
- repeat victimization;
- reported distress;
- extended manipulation associated with some romance or investment cases; and
- whether the reported loss remains unrecovered.

A full recovery reduces the continuing-harm score, although it does not erase the original incident.

## Dispute Friction Score

The Dispute Friction Score estimates how difficult it appears to obtain communication, review, correction, or remediation.

### Inputs

- claim denial;
- case closure without satisfactory resolution;
- no response or no callback;
- repeated calls or contacts;
- transfers among departments;
- duplicative document requests;
- appeals or reconsideration;
- provisional credit removal;
- external complaints or escalation; and
- extended resolution periods.

A reported resolution or reimbursement reduces continuing friction.

## Recovery Urgency Score

The Recovery Urgency Score estimates the time sensitivity of operational actions such as freeze, recall, stop payment, tracing, account security, or evidence preservation.

### Inputs

- payment channel, with faster and less reversible channels receiving higher points;
- APP, bank impersonation, business email compromise, and mule-account typologies;
- overall Fraud Risk Score;
- statements that the event occurred today, yesterday, or within 24 hours;
- pending or processing status;
- recent case date;
- material loss amount; and
- whether funds have already been fully recovered.

This score does not determine whether a recovery action is legally or operationally available.

## Recommendation logic

Recommendations are generated from explicit conditions. Examples include:

- escalate for APP scam review;
- initiate freeze, recall, or stop-payment steps where available;
- review reimbursement eligibility;
- check receiving-side mule-account, device, or beneficiary indicators;
- request additional platform, payment, listing, or communication evidence;
- preserve wallet addresses and transaction hashes;
- monitor for repeat victimization;
- validate medical billing, collection authority, or credit reporting; and
- escalate servicing, insurance, or disclosure-integrity review.

Recommendations are deliberately concise so that they can fit a queue or case-management view. They require analyst judgment.

## Explainability and auditability

The prototype is explainable because every result can be reconstructed from:

- public rule dictionaries in `app.py`;
- matched narrative phrases;
- category weights;
- typology base values;
- transparent point additions and deductions;
- visible thresholds; and
- deterministic recommendation conditions.

An auditor or reviewer can reproduce the same result from the same input. There is no hidden model state.

## Limitations

### Synthetic data

The included data are fictional demonstration cases. They cannot establish real-world accuracy, prevalence, loss rates, protected-class effects, institutional performance, or consumer outcomes.

### Heuristic phrase matching

The MVP may miss paraphrases, spelling errors, negations, sarcasm, complex timelines, multilingual narratives, or emerging schemes. It may also match a phrase even when the narrative denies that the event occurred.

### No factual verification

The tool analyzes reported text. It does not verify identity, authorization, account ownership, transaction records, device data, beneficiary data, sanctions exposure, or source of funds.

### No legal or compliance determination

The output does not decide reimbursement rights, liability, unfair or deceptive conduct, suspicious activity reporting, money laundering, sanctions, consumer-law violations, or criminal conduct.

### Thresholds are not calibrated

Scores and cutoffs were selected for demonstration and interpretability. They require empirical calibration and governance approval before operational use.

### Potential bias and accessibility risks

Narrative quality varies by language, disability, education, access to records, and assistance received. A production system would require multilingual support, accessibility testing, missing-data analysis, bias testing, and safeguards against penalizing consumers for writing style.

### Data privacy and security

A production deployment would need data minimization, encryption, access control, audit logging, retention limits, secure development, incident response, and restrictions on sensitive personal information.

## Improvement with public complaint data

A future research phase could use appropriately licensed and de-identified public complaint data to:

- expand the phrase dictionary;
- measure coverage across complaint products and issues;
- evaluate temporal and geographic trends;
- compare typology predictions with available complaint labels;
- analyze dispute-friction language; and
- test whether harm and urgency indicators identify meaningful subgroups.

Public data may have missing labels, reporting bias, redactions, and nonrepresentative coverage. These limitations should be documented.

## Improvement with institutional data

Subject to lawful access, privacy controls, and governance approval, institutional data could support stronger validation through:

- confirmed fraud and nonfraud case labels;
- transaction timing, channel, amount, and beneficiary features;
- device, account, and authentication indicators;
- recall, freeze, recovery, and reimbursement outcomes;
- receiving-side account and network patterns;
- dispute contacts, evidence requests, and cycle time;
- repeat victimization and linked-case analysis; and
- analyst disposition and quality-review data.

A production program should separate model development, validation, approval, deployment, monitoring, and change control.

## Optional machine-learning extension

A later version could add a simple, interpretable classifier such as TF-IDF with logistic regression or a shallow decision tree. The rules engine should remain available as:

- a benchmark;
- a fallback;
- an explanation layer;
- a source of weak labels for research; and
- a governance control for detecting implausible model outputs.

Any machine-learning extension should report class-level precision, recall, calibration, confusion matrices, subgroup performance, drift, and stability. It should not replace human review for high-impact decisions.

## NIW evidence relevance

As a research artifact, FinGuard-AI shows a proposed endeavor that is concrete rather than general. It operationalizes a defined set of U.S. financial-fraud and consumer-protection problems into a working, inspectable software prototype. The artifact can support evidence of technical planning, domain integration, practical implementation, governance awareness, and a roadmap for research using public or institutional data.

# FinGuard-AI

## U.S. Financial Fraud and Consumer Harm Risk Intelligence Dashboard

**FinGuard-AI is a research prototype. It is not production-ready and must not be used as the sole basis for legal, compliance, reimbursement, account restriction, employment, credit, or other adverse decisions.**

FinGuard-AI is a working Python and Streamlit prototype that converts consumer complaint or fraud narrative text into an explainable case assessment. It demonstrates a specific proposed endeavor focused on U.S. financial fraud, authorized push payment (APP) scams, anti-money laundering (AML) and mule-account risk, dispute friction, recovery urgency, consumer harm, and accountable FinTech governance.

The prototype accepts a single narrative or a CSV portfolio and produces:

- a fraud or risk typology classification;
- Fraud Risk, Consumer Harm, Dispute Friction, and Recovery Urgency scores from 0 to 100;
- the phrases and indicators that influenced the result;
- a practical case recommendation; and
- a portfolio dashboard with case counts, high-risk cases, distributions, averages, severity views, and a high-risk queue.

## Why the tool matters for U.S. financial infrastructure

Digital payments, online account access, instant-transfer channels, remote onboarding, and interconnected institutions can increase convenience while also accelerating fraud losses and the movement of illicit proceeds. A useful risk-intelligence layer should identify not only whether a narrative resembles fraud, but also whether it suggests urgent recovery action, receiving-side mule activity, severe consumer harm, or friction in the dispute process.

FinGuard-AI demonstrates how a governance-oriented analytics tool can organize these signals into a consistent and reviewable workflow. The prototype is designed to support research and evidence development concerning:

- faster identification and triage of APP scams and impersonation schemes;
- receiving-side and pass-through account indicators relevant to AML review;
- early freeze, recall, tracing, or evidence-preservation decisions;
- measurement of unresolved harm and repeat-victimization risk;
- review of denial, delay, repeated-document, and escalation patterns in disputes; and
- transparent model governance through visible scoring rules and audit trails.

## Consumer-protection relevance

Traditional fraud triage can focus narrowly on transaction authorization or confirmed monetary loss. FinGuard-AI adds consumer-centered dimensions: essential-funds impact, medical or housing stress, fixed-income vulnerability, unresolved losses, repeated contacts, prolonged case handling, and recovery time sensitivity.

This broader framework can help researchers and institutions evaluate whether operational controls are identifying the cases that create the greatest practical harm. Recommendations remain advisory and require human review.

## Connection to fraud, AML, APP scams, FinTech governance, and financial stability

### Fraud and APP scams

The rules identify explicit social-engineering and payment-redirection signals, including bank impersonation, false safe-account instructions, one-time passcodes, urgent transfer demands, changed invoice instructions, investment withdrawal fees, and marketplace off-platform payments.

### AML and mule-account risk

The prototype identifies narrative indicators such as receiving funds for another person, keeping a commission, multiple incoming transfers, rapid onward movement, cash-out activity, and pass-through accounts. These indicators are triage signals only; they do not determine that money laundering occurred.

### FinTech governance

Every score is decomposable into visible factors. The user can inspect the matched phrases, point additions or deductions, category alternatives, and recommendation logic. This supports auditability, challenge, documentation, and human oversight.

### Financial stability and infrastructure resilience

Fraud and illicit-funds movement can undermine trust in payment systems and impose operational, liquidity, remediation, and reputational costs. A risk-intelligence workflow that helps prioritize recovery-sensitive cases and recurring typologies can contribute to safer payment operations and stronger consumer confidence. FinGuard-AI demonstrates the concept; it does not quantify systemic risk.

## Project files

- `app.py` — Streamlit application and rules-based analysis engine.
- `sample_data.csv` — 30 realistic but synthetic demonstration cases.
- `requirements.txt` — Python package requirements.
- `methodology.md` — scoring, typology, explainability, limitations, and improvement path.

## Data notice

`sample_data.csv` contains **synthetic demonstration data only**. The narratives are fictional and are not derived from actual consumers, institutions, complaints, investigations, or enforcement matters.

Required CSV columns:

```text
case_id,date,state,narrative,amount_lost,payment_channel,institution_type,outcome
```

## How to run locally

### 1. Create and activate a virtual environment

macOS or Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Start the application

```bash
streamlit run app.py
```

Streamlit will print a local URL, normally `http://localhost:8501`.

## How to use the prototype

### Single narrative

1. Open **Analyze a Narrative**.
2. Enter complaint or fraud text.
3. Add the loss amount, payment channel, and current outcome.
4. Select **Analyze case**.
5. Review the typology, four scores, recommendation, matched indicators, alternatives, and scoring audit trail.

### Portfolio dashboard

1. Open **Portfolio Dashboard**.
2. Use the included synthetic sample or upload a CSV with the required columns.
3. Review the metrics, typology distribution, severity chart, high-risk queue, and analyzed cases.
4. Download the enriched case file.

## Governance and appropriate use

FinGuard-AI should be treated as a research and demonstration artifact. A real deployment would require, at minimum:

- representative data and documented data rights;
- typology and threshold validation;
- false-positive and false-negative analysis;
- fairness and accessibility testing;
- privacy, security, retention, and access controls;
- integration with institutional policies and legal obligations;
- model and rules change management;
- case-review procedures and appeal channels; and
- ongoing monitoring for drift, emerging typologies, and operational outcomes.

See `methodology.md` for the complete scoring and limitation discussion.
